#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <ctype.h>
#include <stdarg.h>
#include "menus.h"
#include "ferramentas.h"


/* ====== PROGRAMA ======*/
int main() {
    telaLogin();
    menuPrincipal();

    return 0;
}
